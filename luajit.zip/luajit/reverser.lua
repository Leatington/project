local function parse(code)
  local matches, data = {}, {}
  for position, type in string['gmatch'](code, '()(["\'])') do
		matches[#matches + 1] = {position = position, type = type}
  end
  table['sort'](matches, function(a, b)
    return a['position'] < b['position']
  end)
  local stop = 0
  for i = 1, #matches do
    local start, result, symbol = matches[i]['position'], nil, nil
    if start > stop then
      stop = matches[i]['position']
      while symbol ~= matches[i]['type'] do
        result, stop, symbol = string['find'](code, '(\\?.)', stop + 1)
        assert(result, 'Parsing error.')
      end
			data[#data + 1] = {start = matches[i]['position'], stop = stop, value = string['sub'](code, matches[i]['position'] + 1, stop - 1)}
    end
  end
  return data
end

local replace_functions = {
	{'function onSystemInitialized%(%)', '_G[\'onSystemInitialized\'] = function()'},
	{'function main%(%)', '_G[\'main\'] = function()'}
}

local replace_variables = {
  -- MoonLoader functions:
  {'addEventHandler%((.+)%)', 'addEventHandler'},

  {'doesFileExist', 'doesFileExist%((.+)%)', 'doesFileExist'},
  {'downloadUrlToFile%((.+)%)', 'downloadUrlToFile'},
  {'getGameDirectory%(%)', 'getGameDirectory'},
  {'getFolderPath%((.+)%)', 'getFolderPath'},
  {'getWorkingDirectory%(%)', 'getWorkingDirectory'},
  {'lua_thread%[', 'lua_thread'},
  {'reloadScripts%(%)', 'reloadScripts'},
  {'thisScript%(%)', 'thisScript'},


  -- MoonLoader defines:
  {'script%[', 'script'},
  {'script_properties%((.+)%)', 'script_properties'},
  {'script_version_number%((%d+)%)', 'script_version_number'},

  -- Lua functions:
  {'io%[(.+)%)%]', 'io'},
  {'math%[', 'math'},
  {'os%[', 'os'},
  {'pairs%((.+)%)', 'pairs'},
  {'pcall%((.+)%)', 'pcall'},
    {'decodeJson,', 'decodeJson'},
  {'require%((.+)%)', 'require'},
  {'string%[', 'string'},
  {'tonumber%((.+)%)', 'tonumber'},
  {'type%((.+)%)', 'type'},
  {'wait%((.+)%)', 'wait'}

  -- SampFuncs functions:
}

local result = [[
local function flip(text)
	local temp = ''
	for i = #text, 1, -1 do
		temp = temp .. _G['string']['sub'](text, i, i)
	end
	return temp
end

]]

for line in io['lines']('result.lua') do
	for i = 1, #replace_functions do
    if string['find'](line, replace_functions[i][1]) then
      line = string['gsub'](line, replace_functions[i][1], replace_functions[i][2])
    end
  end
  for i = 1, #replace_variables do
    if string['find'](line, replace_variables[i][1]) then
      line = string['gsub'](line, replace_variables[i][2], '_G[\'' .. replace_variables[i][2] .. '\']')
    end
  end
  local line_parse = parse(line)
  if #line_parse >= 1 then
    for i = 1, #line_parse do
      local temp = string['sub'](line, line_parse[i]['stop'] + 1, #line)
      line = string['sub'](line, 1, line_parse[i]['start'] - 1) .. 'flip(' .. string['sub'](line, line_parse[i]['start'], line_parse[i]['start']) .. string['reverse'](line_parse[i]['value']) .. string['sub'](line, line_parse[i]['start'], line_parse[i]['start']) .. ')' .. temp
      line_parse = parse(line)
    end
  end
  result = result .. line .. '\n'
end

local file = io['open']('file.lua', 'w+')
if file then
	io['output'](file)
	io['write'](result)
  io['close'](file)
end